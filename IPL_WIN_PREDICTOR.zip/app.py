import streamlit as st
import pickle
import pandas as pd

# Define team and city lists
teams = ['Sunrisers Hyderabad', 'Mumbai Indians', 'Royal Challengers Bangalore', 'Kolkata Knight Riders',
         'Punjab Kings', 'Chennai Super Kings', 'Rajasthan Royals', 'Delhi Capitals']

cities = ['Hyderabad', 'Bangalore', 'Mumbai', 'Indore', 'Kolkata', 'Delhi',
          'Chandigarh', 'Jaipur', 'Chennai', 'Cape Town', 'Port Elizabeth',
          'Durban', 'Centurion', 'East London', 'Johannesburg', 'Kimberley',
          'Bloemfontein', 'Ahmedabad', 'Cuttack', 'Nagpur', 'Dharamsala',
          'Visakhapatnam', 'Pune', 'Raipur', 'Ranchi', 'Abu Dhabi',
          'Sharjah', 'Mohali', 'Bengaluru']

# Load the model
pipe = pickle.load(open('pipe.pkl', 'rb'))

# Set page title and add some style
st.title('IPL Win Predictor')
st.markdown(
    """
    <style>
        .main {
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #ff6347;
        }
        .btn {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# Create two columns
col1, col2 = st.columns(2)

# Column 1: Batting team selection
with col1:
    batting_team = st.selectbox('Select the batting team', sorted(teams))

# Column 2: Bowling team selection
with col2:
    bowling_team = st.selectbox('Select the bowling team', sorted(teams))

# Additional styling for the input form
st.markdown("<hr style='margin: 20px 0;'>", unsafe_allow_html=True)
selected_city = st.selectbox('Select city', sorted(cities))
target = st.number_input('Target')

# Create three columns for score, overs, and wickets input
col3, col4, col5 = st.columns(3)

# Column 3: Score input
with col3:
    score = st.number_input('Score')

# Column 4: Overs input
with col4:
    overs = st.number_input('Overs completed')

# Column 5: Wickets input
with col5:
    wickets = st.number_input('Wickets lost')

# Prediction button with styling
if st.button('Predict Win Probability', key='predict_btn'):
    runs_left = target - score
    balls_left = 120 - (overs * 6)
    wickets = 10 - wickets
    crr = score / overs
    rrr = (runs_left * 6) / balls_left

    input_df = pd.DataFrame({'batting_team': [batting_team], 'bowling_team': [bowling_team],
                              'city': [selected_city], 'runs_left': [runs_left], 'balls_left': [balls_left],
                              'wickets': [wickets], 'total_runs_x': [target], 'crr': [crr], 'rrr': [rrr]})


    result = pipe.predict_proba(input_df)

    loss = result[0][0]
    win = result[0][1]

    # Display results with styling
    st.markdown("<hr style='margin: 20px 0;'>", unsafe_allow_html=True)
    st.markdown(f"**{batting_team}** - {round(win * 100)}%", unsafe_allow_html=True)
    st.markdown(f"**{bowling_team}** - {round(loss * 100)}%", unsafe_allow_html=True)
